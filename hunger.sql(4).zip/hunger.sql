-- phpMyAdmin SQL Dump
-- version 4.8.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 01, 2019 at 09:04 PM
-- Server version: 10.1.33-MariaDB
-- PHP Version: 7.2.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hunger`
--

-- --------------------------------------------------------

--
-- Table structure for table `cat`
--

CREATE TABLE `cat` (
  `cid` varchar(50) NOT NULL,
  `cname` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cat`
--

INSERT INTO `cat` (`cid`, `cname`) VALUES
('C1', 'df'),
('C2', 'drinks'),
('C3', 'cake'),
('C4', 'ice');

-- --------------------------------------------------------

--
-- Table structure for table `deliveryboy`
--

CREATE TABLE `deliveryboy` (
  `did` varchar(50) NOT NULL,
  `dname` varchar(50) NOT NULL,
  `dphone` varchar(100) NOT NULL,
  `demail` varchar(50) NOT NULL,
  `hid` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `deliveryboy`
--

INSERT INTO `deliveryboy` (`did`, `dname`, `dphone`, `demail`, `hid`) VALUES
('D1', 'rohit', '8767868', 'rohit@gmail.com', 'H1001'),
('D2', 'Rahul Sharma', '7089645143', 'rahul@gmail.com', 'H1001'),
('D3', 'Punit', '8767868', 'punit@gmail.com', 'H1001');

-- --------------------------------------------------------

--
-- Table structure for table `hotel_add`
--

CREATE TABLE `hotel_add` (
  `hid` varchar(50) NOT NULL,
  `name` varchar(50) NOT NULL,
  `city` varchar(50) NOT NULL,
  `hphone` varchar(70) NOT NULL,
  `type` varchar(50) NOT NULL,
  `pwd` varchar(50) NOT NULL,
  `address` varchar(200) NOT NULL,
  `status` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hotel_add`
--

INSERT INTO `hotel_add` (`hid`, `name`, `city`, `hphone`, `type`, `pwd`, `address`, `status`) VALUES
('H1001', 'Hari Raj', 'Bhilai', '9907180449', 'Veg', 'H1001', 'Civic Center,Bhilai', 'active'),
('H1002', '90\'s cafe', 'Bhilai', '9907180', 'Veg', 'H1002', 'Bhilai', 'active'),
('H1003', 'Hotel Amit ', 'Bhilai', '9907180441', 'Non-Veg', 'H1003', 'bhilai', 'active'),
('H1004', 'Hotel Al Zaqia', 'Bhilai', '9987765412', 'Both', 'H1004', 'Nehru nagar', 'active'),
('H1005', 'ertet', 'Durg', '5465465', 'Non-Veg', 'H1005', 'dtd ', 'active'),
('H1007', 'Sholay', 'Bhilai', '7878674591', 'Veg', 'H1007', 'Supela ', 'active'),
('H1008', 'Glassy Hotel', 'Bhilai', '8976651210', 'Veg', 'H1008', 'durg', 'active'),
('H1009', 'HAVELI ', 'Bhilai', '098765432', 'Both', 'H1009', 'NEHRU NAGER EAST BHILAI C.G', 'active'),
('H1010', 'CAFETERIA', 'Durg', '8085667218', 'Veg', 'H1010', 'DURG NEAR BY SHIVNATH ', 'active'),
('H1011', 'HIPSTER', 'Bhilai', '797641321', 'Veg', 'H1011', 'NEHRU-NAGER ', 'active'),
('H1012', 'H3 CAFE', 'Bhilai', '7974512378', 'Veg', 'H1012', 'NEHRU NAGER EAST BHILAI C.G', 'active'),
('H1013', 'LAZEEZ', 'Durg', '8907653142', 'Non-Veg', 'H1013', 'DURG NEAR BY SHIVNATH ', 'active'),
('H1014', 'ROOFTUFF', 'Durg', '123654789', 'Both', 'H1014', 'bhilai', 'active'),
('H1015', 'VRINDAVAN', 'Durg', '8085887318', 'Both', 'H1015', 'DURG NEAR BY SHIVNATH ', 'active'),
('H1016', 'CG-04', 'Bhilai', '1987563729', 'Veg', 'H1016', 'Smriti Nager west BHILAI', 'active'),
('H1017', 'H3', 'Durg', '9907180449', 'Both', 'H1017', 'bhilai', 'active');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `loginid` varchar(50) NOT NULL,
  `pwd` varchar(50) NOT NULL,
  `role` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`loginid`, `pwd`, `role`) VALUES
('admin', 'admin', 'admin'),
('H1001', '0101', 'hadmin'),
('H1002', 'H1002', 'hadmin'),
('H1003', 'H1003', 'hadmin'),
('H1004', 'H1004', 'hadmin'),
('H1017', 'H1017', 'hadmin'),
('nisha', '0101', 'user'),
('pliyu@', '121', 'user'),
('Yash@', '010101', 'user'),
('yashpay', '010101', 'user');

-- --------------------------------------------------------

--
-- Table structure for table `menu`
--

CREATE TABLE `menu` (
  `mid` varchar(50) NOT NULL,
  `mname` varchar(50) NOT NULL,
  `hprice` varchar(50) NOT NULL,
  `spec` varchar(250) NOT NULL,
  `catid` varchar(50) NOT NULL,
  `hid` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `menu`
--

INSERT INTO `menu` (`mid`, `mname`, `hprice`, `spec`, `catid`, `hid`) VALUES
('M201', 'cake', '120', ' gu  ty n6sr tyuy ', 'C3', 'H1001'),
('M202', 'burger', '120', 'r gety      5 ryu tyu 57ury', 'C1', 'H1001'),
('M203', 'paneer kadai', '220', 'etgvb 46 ygh', 'C1', 'H1001'),
('M204', 'ice', '122', 'e2r tr etg', 'C3', 'H1002'),
('M205', 'maggie', '30', 'hunger finisher\r\n', 'C1', 'H1001'),
('M206', 'DOSA & UTTAPAM', '100', '', 'C1', 'H1001'),
('M207', 'FRUIT-SALAD', '140', '', 'C1', 'H1001'),
('M208', 'VEGGIE PARADISE PIZZA', '400', '', 'C1', 'H1001'),
('M209', 'CHINESE PLATTER', '400', '', 'C1', 'H1001'),
('M210', 'CHOCLATE PASTRY', '60', '', 'C3', 'H1001'),
('M211', 'BIRYANI(veg)', '360', '', 'C1', 'H1001'),
('M212', 'MOMOS', '100', '', 'C1', 'H1001'),
('M213', 'BLACK-FOREST(CHOCLATE)CAKE', '600', '', 'C3', 'H1001'),
('M214', 'UTTAPAM', '100', '', 'C1', 'nisha'),
('M215', 'PURI-BHAJI', '140', '', 'C1', 'H1001'),
('M216', 'STRAWBERRY-SHAKE', '70', '', 'C1', 'H1001'),
('M217', 'GULAB-JAMUN', '400', '', 'C1', 'H1001'),
('M218', 'FINGER-FRIES', '180', '', 'C1', 'H1001');

-- --------------------------------------------------------

--
-- Table structure for table `orderc`
--

CREATE TABLE `orderc` (
  `oid` varchar(50) NOT NULL,
  `mid` varchar(50) NOT NULL,
  `price` varchar(50) NOT NULL,
  `qty` varchar(50) NOT NULL,
  `tprice` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `orderc`
--

INSERT INTO `orderc` (`oid`, `mid`, `price`, `qty`, `tprice`) VALUES
('111', 'M201', '120', '1', '120'),
('111', 'M202', '120', '1', '120'),
('111', 'M203', '220', '1', '220'),
('112', 'M201', '120', '1', '120'),
('113', 'M201', '120', '1', '120'),
('113', 'M202', '120', '1', '120'),
('114', 'M201', '120', '1', '120'),
('114', 'M202', '120', '1', '120'),
('114', 'M203', '220', '1', '220'),
('115', 'M202', '120', '1', '120'),
('115', 'M201', '120', '1', '120'),
('116', 'M201', '120', '1', '120'),
('116', 'M201', '120', '1', '120'),
('116', 'M203', '220', '1', '220'),
('117', 'M201', '120', '1', '120'),
('117', 'M202', '120', '1', '120'),
('118', 'M201', '120', '1', '120'),
('118', 'M202', '120', '1', '120'),
('119', 'M201', '120', '1', '120'),
('119', 'M202', '120', '1', '120'),
('120', 'M201', '120', '1', '120'),
('120', 'M202', '120', '1', '120'),
('121', 'M204', '122', '1', '122'),
('122', 'M204', '122', '1', '122'),
('123', 'M203', '220', '1', '220'),
('124', 'M201', '120', '1', '120'),
('124', 'M202', '120', '1', '120'),
('125', 'M216', '70', '1', '70'),
('125', 'M212', '100', '1', '100'),
('126', 'M201', '120', '1', '120'),
('126', 'M202', '120', '1', '120'),
('126', 'M203', '220', '1', '220'),
('127', 'M201', '120', '1', '120'),
('127', 'M202', '120', '1', '120'),
('127', 'M203', '220', '1', '220'),
('128', 'M216', '70', '1', '70'),
('128', 'M205', '30', '1', '30'),
('128', 'M203', '220', '1', '220'),
('129', 'M218', '180', '1', '180'),
('129', 'M203', '220', '1', '220'),
('129', 'M202', '120', '1', '120'),
('129', 'M201', '120', '1', '120'),
('129', 'M202', '120', '1', '120'),
('130', 'M201', '120', '1', '120'),
('130', 'M203', '220', '1', '220'),
('131', 'M205', '30', '1', '30'),
('132', 'M205', '30', '1', '30'),
('133', 'M205', '30', '1', '30'),
('118', 'M201', '120', '1', '120'),
('118', 'M202', '120', '1', '120'),
('118', 'M203', '220', '1', '220'),
('119', 'M201', '120', '1', '120'),
('119', 'M202', '120', '1', '120'),
('119', 'M203', '220', '1', '220'),
('235', 'M205', '30', '1', '30'),
('235', 'M203', '220', '1', '220'),
('112', 'M205', '30', '1', '30'),
('112', 'M203', '220', '1', '220');

-- --------------------------------------------------------

--
-- Table structure for table `orderm`
--

CREATE TABLE `orderm` (
  `oid` varchar(50) NOT NULL,
  `odate` varchar(50) NOT NULL,
  `loginid` varchar(50) NOT NULL,
  `payamt` varchar(50) NOT NULL,
  `phone` varchar(100) NOT NULL,
  `address` varchar(500) NOT NULL,
  `hid` varchar(50) NOT NULL,
  `status` varchar(50) NOT NULL,
  `delivery_boy` varchar(50) NOT NULL,
  `time` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `orderm`
--

INSERT INTO `orderm` (`oid`, `odate`, `loginid`, `payamt`, `phone`, `address`, `hid`, `status`, `delivery_boy`, `time`) VALUES
('112', '04/01/13', 'Yash@', '250&#8377;', '7890123243', 'mother teresa nagar camp1', 'H1001', 'pending', 'none', '12:45');

-- --------------------------------------------------------

--
-- Table structure for table `user_detail`
--

CREATE TABLE `user_detail` (
  `loginid` varchar(50) NOT NULL,
  `uname` varchar(50) NOT NULL,
  `phone` varchar(50) NOT NULL,
  `email` varchar(70) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_detail`
--

INSERT INTO `user_detail` (`loginid`, `uname`, `phone`, `email`) VALUES
('nisha', 'dummy', '53435433', 'nisha1312verma@gmail.com'),
('pliyu@', 'pliyu', '990', '123priyankadubey@gmail.com'),
('vgh', 'fgsdg', '345444545', '123pbniyankadubey@gmail.com'),
('Yash@', 'Yashpal Singh', '9907180449', 'yassingh49@gmail.com'),
('yashpay', 'yash', '345454', 'yassingh49@gmail.com');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `deliveryboy`
--
ALTER TABLE `deliveryboy`
  ADD PRIMARY KEY (`did`);

--
-- Indexes for table `hotel_add`
--
ALTER TABLE `hotel_add`
  ADD PRIMARY KEY (`hid`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`loginid`);

--
-- Indexes for table `menu`
--
ALTER TABLE `menu`
  ADD PRIMARY KEY (`mid`);

--
-- Indexes for table `orderm`
--
ALTER TABLE `orderm`
  ADD PRIMARY KEY (`oid`);

--
-- Indexes for table `user_detail`
--
ALTER TABLE `user_detail`
  ADD PRIMARY KEY (`loginid`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
